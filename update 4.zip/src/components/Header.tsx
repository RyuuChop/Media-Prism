import { Heart, ImageIcon, Music, ShieldCheck, Sparkles, Zap } from "lucide-react";
import { cn } from "../utils/cn";

export default function Header({
  activeMode,
  onModeChange,
  onOpenSupport,
}: {
  activeMode: "all" | "audio" | "image";
  onModeChange: (mode: "all" | "audio" | "image") => void;
  onOpenSupport?: () => void;
}) {
  return (
    <header className="py-6 border-b border-white/5 space-y-4">
      {/* Top Bar with Creator Support Badge */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Creator Support Persistent Badge */}
        <div className="flex items-center gap-2 rounded-full border border-indigo-400/30 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 px-3.5 py-1.5 backdrop-blur-md shadow-sm">
          <button
            type="button"
            onClick={onOpenSupport}
            className="flex items-center gap-1.5 font-medium text-slate-300 hover:text-pink-300 transition-colors"
            title="View creator support channels"
          >
            <Heart className="h-3.5 w-3.5 text-pink-400 fill-pink-400/80 animate-pulse" />
            <span className="font-semibold text-slate-200">Supported by</span>
            <span className="font-mono text-pink-400 font-bold hover:underline">@X_RyuuChop_X</span>
          </button>

          <div className="h-3.5 w-px bg-white/15 mx-0.5" />

          <div className="flex items-center gap-2">
            {/* YouTube */}
            <a
              href="https://youtube.com/@X_RYUUCHOP_X"
              target="_blank"
              rel="noopener noreferrer"
              className="p-1 text-slate-400 hover:text-red-400 transition-colors"
              title="YouTube: @X_RYUUCHOP_X"
              aria-label="YouTube"
            >
              <svg className="h-3.5 w-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </a>

            {/* TikTok */}
            <a
              href="https://tiktok.com/@x_ryuuchop_x"
              target="_blank"
              rel="noopener noreferrer"
              className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
              title="TikTok: x_ryuuchop_x"
              aria-label="TikTok"
            >
              <svg className="h-3.5 w-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </a>

            {/* Instagram */}
            <a
              href="https://instagram.com/X_RyuuChop_X"
              target="_blank"
              rel="noopener noreferrer"
              className="p-1 text-slate-400 hover:text-pink-400 transition-colors"
              title="Instagram: X_RyuuChop_X"
              aria-label="Instagram"
            >
              <svg className="h-3.5 w-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>
          </div>
        </div>

        {/* Security & Client-Side indicators */}
        <div className="flex items-center gap-2.5 ml-auto">
          <div className="flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-300">
            <ShieldCheck className="h-3.5 w-3.5" />
            100% In-Browser · Zero Server Lag
          </div>

          <div className="flex items-center gap-1.5 rounded-full border border-indigo-400/20 bg-indigo-500/10 px-3 py-1 text-[11px] font-medium text-indigo-300">
            <Zap className="h-3.5 w-3.5" />
            Instant Processing
          </div>
        </div>
      </div>

      {/* Main Branding & Navigation Row */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 opacity-60 blur-lg" />
            <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-950/60 ring-1 ring-white/20">
              <Sparkles className="h-5.5 w-5.5 text-white" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold tracking-tight text-white">
                Media<span className="text-gradient">Forge</span>
              </h1>
              <span className="rounded-full border border-indigo-400/30 bg-indigo-500/15 px-2 py-0.5 text-[10px] font-bold tracking-widest text-indigo-300">
                STUDIO
              </span>
            </div>
            <p className="text-xs font-medium text-slate-400">
              High-Speed Image Studio & Audio Converter
            </p>
          </div>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="flex rounded-xl border border-white/10 bg-white/5 p-1">
          <button
            type="button"
            onClick={() => onModeChange("all")}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all",
              activeMode === "all"
                ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white shadow-md"
                : "text-slate-400 hover:text-white",
            )}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>All Formats</span>
          </button>

          <button
            type="button"
            onClick={() => onModeChange("image")}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all",
              activeMode === "image"
                ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white shadow-md"
                : "text-slate-400 hover:text-white",
            )}
          >
            <ImageIcon className="h-3.5 w-3.5" />
            <span>Image Studio</span>
          </button>

          <button
            type="button"
            onClick={() => onModeChange("audio")}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all",
              activeMode === "audio"
                ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white shadow-md"
                : "text-slate-400 hover:text-white",
            )}
          >
            <Music className="h-3.5 w-3.5" />
            <span>Audio Studio</span>
          </button>
        </div>
      </div>
    </header>
  );
}
